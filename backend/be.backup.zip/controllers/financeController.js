const { Sale, SaleItem, Expense, ExpenseCategory, Branch, Product, Service, ServiceItem, Payment, Customer } = require("../models");
const { Op } = require("sequelize");

function getOrganizationId(req) {
  const id = req.user?.organizationId ?? req.staff?.organizationId;
  if (!id) {
    const err = new Error("Organization context required");
    err.statusCode = 403;
    throw err;
  }
  return id;
}

async function getBranchIdFromHeader(req, organizationId) {
  const raw = req.headers["x-branch-id"];
  if (raw == null || raw === "") return null;
  const branchId = parseInt(raw, 10);
  if (Number.isNaN(branchId)) return null;
  const branch = await Branch.findOne({ where: { id: branchId, organizationId } });
  return branch ? branch.id : null;
}

/** Parse query into period start/end. Supports fromDate&toDate (YYYY-MM-DD) or month&year (single month). */
function getPeriodFromRequest(req) {
  const fromDate = req.query.fromDate != null ? String(req.query.fromDate).trim() : null;
  const toDate = req.query.toDate != null ? String(req.query.toDate).trim() : null;
  const now = new Date();

  if (fromDate && toDate) {
    const start = new Date(fromDate);
    const end = new Date(toDate);
    if (!Number.isNaN(start.getTime()) && !Number.isNaN(end.getTime()) && start <= end) {
      start.setHours(0, 0, 0, 0);
      end.setHours(23, 59, 59, 999);
      const startStr = `${start.getFullYear()}-${String(start.getMonth() + 1).padStart(2, "0")}-${String(start.getDate()).padStart(2, "0")}`;
      const endStr = `${end.getFullYear()}-${String(end.getMonth() + 1).padStart(2, "0")}-${String(end.getDate()).padStart(2, "0")}`;
      return { periodStart: start, periodEnd: end, periodStartStr: startStr, periodEndStr: endStr, isRange: true };
    }
  }

  const month = req.query.month != null ? parseInt(req.query.month, 10) : null;
  const year = req.query.year != null ? parseInt(req.query.year, 10) : null;
  const y = year != null && !Number.isNaN(year) ? year : now.getFullYear();
  const m = month != null && !Number.isNaN(month) && month >= 1 && month <= 12 ? month : now.getMonth() + 1;
  const periodStart = new Date(y, m - 1, 1);
  const periodEnd = new Date(y, m, 0, 23, 59, 59, 999);
  const periodStartStr = `${y}-${String(m).padStart(2, "0")}-01`;
  const periodEndStr = `${y}-${String(m).padStart(2, "0")}-${String(new Date(y, m, 0).getDate()).padStart(2, "0")}`;
  return { periodStart, periodEnd, periodStartStr, periodEndStr, isRange: false, month: m, year: y };
}

/**
 * GET /api/finance/profit-loss?month=3&year=2026  OR  ?fromDate=2026-03-01&toDate=2026-06-30
 * Returns P&L for the period: revenue (from Sales), COGS, expenses by category, gross profit, net profit.
 * X-Branch-Id optional for branch-scoped.
 */
async function getProfitLoss(req, res) {
  try {
    const organizationId = getOrganizationId(req);
    const branchId = await getBranchIdFromHeader(req, organizationId);

    const { periodStart, periodEnd, periodStartStr, periodEndStr, isRange, month: m, year: y } = getPeriodFromRequest(req);
    const monthStart = periodStart;
    const monthEnd = periodEnd;
    const monthStartStr = periodStartStr;
    const monthEndStr = periodEndStr;

    const saleWhere = { organizationId, status: "paid", createdAt: { [Op.gte]: monthStart, [Op.lte]: monthEnd } };
    if (branchId != null) saleWhere.branchId = branchId;

    const revenueResult = await Sale.sum("total", { where: saleWhere });
    const revenue = revenueResult != null ? Number(revenueResult) : 0;

    // COGS = same as Sales Dashboard: only "POS Sale #" utilization for paid sales that still exist, in this month
    const serviceWhere = {
      organizationId,
      serviceName: { [Op.like]: "POS Sale #%" },
      date: { [Op.gte]: monthStart, [Op.lte]: monthEnd },
    };
    if (branchId != null) serviceWhere.branchId = branchId;
    const posSaleServices = await Service.findAll({
      where: serviceWhere,
      attributes: ["id", "serviceName"],
      include: [
        { model: ServiceItem, as: "ServiceItems", required: true, attributes: ["quantity"], include: [{ model: Product, as: "Product", attributes: ["purchasePriceExc"] }] },
      ],
    });
    const saleIdsInPeriod = new Set(
      (await Sale.findAll({ where: saleWhere, attributes: ["id"] })).map((s) => s.id)
    );
    let cogs = 0;
    for (const svc of posSaleServices) {
      const match = (svc.serviceName || "").match(/^POS Sale #(\d+)$/);
      const saleId = match ? parseInt(match[1], 10) : null;
      if (saleId == null || !saleIdsInPeriod.has(saleId)) continue;
      for (const it of svc.ServiceItems || []) {
        const qty = parseFloat(it.quantity) || 0;
        const cost = it.Product && it.Product.purchasePriceExc != null ? parseFloat(it.Product.purchasePriceExc) || 0 : 0;
        cogs += qty * cost;
      }
    }

    const expWhere = { organizationId, date: { [Op.gte]: monthStartStr, [Op.lte]: monthEndStr } };
    if (branchId != null) expWhere.branchId = branchId;

    const expenses = await Expense.findAll({
      where: expWhere,
      include: [{ model: ExpenseCategory, as: "ExpenseCategory", attributes: ["id", "name"] }],
      attributes: ["id", "categoryId", "amount", "date"],
    });

    let totalExpenses = 0;
    const byCategory = {};

    for (const exp of expenses) {
      const amount = parseFloat(exp.amount) || 0;
      totalExpenses += amount;
      const cat = exp.ExpenseCategory;
      const catName = cat ? (cat.name || "Other") : "Other";
      if (!byCategory[catName]) byCategory[catName] = 0;
      byCategory[catName] += amount;
    }

    const grossProfit = revenue - cogs;
    const netProfit = revenue - totalExpenses;

    const expensesByCategory = Object.entries(byCategory).map(([name, amount]) => ({ categoryName: name, amount: Math.round(amount * 100) / 100 })).sort((a, b) => b.amount - a.amount);

    const period = isRange ? { fromDate: monthStartStr, toDate: monthEndStr } : { month: m, year: y };
    return res.status(200).json({
      success: true,
      data: {
        period,
        revenue: Math.round(revenue * 100) / 100,
        cogs: Math.round(cogs * 100) / 100,
        grossProfit: Math.round(grossProfit * 100) / 100,
        totalExpenses: Math.round(totalExpenses * 100) / 100,
        expensesByCategory,
        netProfit: Math.round(netProfit * 100) / 100,
      },
    });
  } catch (err) {
    if (err.statusCode === 403) return res.status(403).json({ success: false, message: err.message });
    console.error("finance getProfitLoss error:", err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
}

/**
 * GET /api/finance/cash-flow?month=3&year=2026  OR  ?fromDate=2026-03-01&toDate=2026-06-30
 * Returns cash flow for the period: inflows (Sales), outflows (Cost of Goods Sold/COGS, Expenses by category), net cash flow.
 * X-Branch-Id optional for branch-scoped.
 */
async function getCashFlow(req, res) {
  try {
    const organizationId = getOrganizationId(req);
    const branchId = await getBranchIdFromHeader(req, organizationId);

    const { periodStart, periodEnd, periodStartStr, periodEndStr, isRange, month: m, year: y } = getPeriodFromRequest(req);
    const monthStart = periodStart;
    const monthEnd = periodEnd;
    const monthStartStr = periodStartStr;
    const monthEndStr = periodEndStr;

    const saleWhere = { organizationId, status: "paid", createdAt: { [Op.gte]: monthStart, [Op.lte]: monthEnd } };
    if (branchId != null) saleWhere.branchId = branchId;

    const revenueResult = await Sale.sum("total", { where: saleWhere });
    const salesInflow = revenueResult != null ? Number(revenueResult) : 0;

    // COGS = cost of inventory (goods sold) – same logic as P&L
    const serviceWhere = {
      organizationId,
      serviceName: { [Op.like]: "POS Sale #%" },
      date: { [Op.gte]: monthStart, [Op.lte]: monthEnd },
    };
    if (branchId != null) serviceWhere.branchId = branchId;
    const posSaleServices = await Service.findAll({
      where: serviceWhere,
      attributes: ["id", "serviceName"],
      include: [
        { model: ServiceItem, as: "ServiceItems", required: true, attributes: ["quantity"], include: [{ model: Product, as: "Product", attributes: ["purchasePriceExc"] }] },
      ],
    });
    const saleIdsInPeriod = new Set(
      (await Sale.findAll({ where: saleWhere, attributes: ["id"] })).map((s) => s.id)
    );
    let stockCost = 0;
    for (const svc of posSaleServices) {
      const match = (svc.serviceName || "").match(/^POS Sale #(\d+)$/);
      const saleId = match ? parseInt(match[1], 10) : null;
      if (saleId == null || !saleIdsInPeriod.has(saleId)) continue;
      for (const it of svc.ServiceItems || []) {
        const qty = parseFloat(it.quantity) || 0;
        const cost = it.Product && it.Product.purchasePriceExc != null ? parseFloat(it.Product.purchasePriceExc) || 0 : 0;
        stockCost += qty * cost;
      }
    }

    const expWhere = { organizationId, date: { [Op.gte]: monthStartStr, [Op.lte]: monthEndStr } };
    if (branchId != null) expWhere.branchId = branchId;

    const expenses = await Expense.findAll({
      where: expWhere,
      include: [{ model: ExpenseCategory, as: "ExpenseCategory", attributes: ["id", "name"] }],
      attributes: ["id", "categoryId", "amount", "date"],
    });

    const outflows = [];
    outflows.push({ label: "Cost of Goods Sold (COGS)", amount: Math.round(stockCost * 100) / 100 });

    const byCategory = {};
    for (const exp of expenses) {
      const amount = parseFloat(exp.amount) || 0;
      const cat = exp.ExpenseCategory;
      const catName = cat ? (cat.name || "Other") : "Other";
      if (!byCategory[catName]) byCategory[catName] = 0;
      byCategory[catName] += amount;
    }
    const expensesByCategory = Object.entries(byCategory)
      .map(([name, amount]) => ({ label: name, amount: Math.round(amount * 100) / 100 }))
      .sort((a, b) => b.amount - a.amount);
    outflows.push(...expensesByCategory);

    const totalInflow = Math.round(salesInflow * 100) / 100;
    const totalOutflow = outflows.reduce((sum, o) => sum + o.amount, 0);
    const netCashFlow = Math.round((totalInflow - totalOutflow) * 100) / 100;

    const period = isRange ? { fromDate: monthStartStr, toDate: monthEndStr } : { month: m, year: y };
    return res.status(200).json({
      success: true,
      data: {
        period,
        inflows: [{ label: "Sales", amount: totalInflow }],
        outflows,
        totalInflow,
        totalOutflow: Math.round(totalOutflow * 100) / 100,
        netCashFlow,
      },
    });
  } catch (err) {
    if (err.statusCode === 403) return res.status(403).json({ success: false, message: err.message });
    console.error("finance getCashFlow error:", err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
}

/**
 * GET /api/finance/receivables
 * Returns receivables: Unpaid Sales, Pending Client Payments (partial), Total Receivables, and list of outstanding sales.
 * X-Branch-Id optional for branch-scoped.
 */
async function getReceivables(req, res) {
  try {
    const organizationId = getOrganizationId(req);
    const branchId = await getBranchIdFromHeader(req, organizationId);

    const where = { organizationId, status: { [Op.in]: ["unpaid", "partial"] } };
    if (branchId != null) where.branchId = branchId;

    const sales = await Sale.findAll({
      where,
      include: [
        { model: Payment, as: "Payments", attributes: ["id", "amount", "paymentMethod", "createdAt"] },
        { model: Customer, as: "Customer", attributes: ["id", "name", "mobile"], required: false },
      ],
      order: [["createdAt", "DESC"]],
    });

    let unpaidSalesTotal = 0;
    let pendingFromPartialTotal = 0;
    const items = [];

    for (const sale of sales) {
      const total = parseFloat(sale.total) || 0;
      const totalPaid = (sale.Payments || []).reduce((s, p) => s + (parseFloat(p.amount) || 0), 0);
      const remainingBalance = Math.round((total - totalPaid) * 100) / 100;
      const customer = sale.Customer;

      if (sale.status === "unpaid") {
        unpaidSalesTotal += total;
      } else {
        pendingFromPartialTotal += remainingBalance;
      }

      items.push({
        id: sale.id,
        customerName: customer ? customer.name : null,
        customerPhone: customer ? customer.mobile : null,
        createdAt: sale.createdAt,
        total: Math.round(total * 100) / 100,
        totalPaid: Math.round(totalPaid * 100) / 100,
        remainingBalance,
        status: sale.status,
      });
    }

    unpaidSalesTotal = Math.round(unpaidSalesTotal * 100) / 100;
    pendingFromPartialTotal = Math.round(pendingFromPartialTotal * 100) / 100;
    const totalReceivables = Math.round((unpaidSalesTotal + pendingFromPartialTotal) * 100) / 100;

    return res.status(200).json({
      success: true,
      data: {
        summary: {
          unpaidSalesTotal,
          pendingFromPartialTotal,
          totalReceivables,
          unpaidCount: sales.filter((s) => s.status === "unpaid").length,
          partialCount: sales.filter((s) => s.status === "partial").length,
        },
        items,
      },
    });
  } catch (err) {
    if (err.statusCode === 403) return res.status(403).json({ success: false, message: err.message });
    console.error("finance getReceivables error:", err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
}

/**
 * GET /api/finance/revenue-breakdown?fromDate=...&toDate=...
 * Returns paid sales in period with line items (service name, price, quantity, line total) for the amount-detail dialog.
 */
async function getRevenueBreakdown(req, res) {
  try {
    const organizationId = getOrganizationId(req);
    const branchId = await getBranchIdFromHeader(req, organizationId);
    const { periodStart, periodEnd, periodStartStr, periodEndStr } = getPeriodFromRequest(req);

    const saleWhere = { organizationId, status: "paid", createdAt: { [Op.gte]: periodStart, [Op.lte]: periodEnd } };
    if (branchId != null) saleWhere.branchId = branchId;

    const sales = await Sale.findAll({
      where: saleWhere,
      include: [{ model: SaleItem, as: "SaleItems", attributes: ["itemName", "price", "quantity"] }],
      order: [["createdAt", "ASC"]],
    });

    const salesData = [];
    let totalRevenue = 0;
    for (const sale of sales) {
      const total = parseFloat(sale.total) || 0;
      totalRevenue += total;
      const items = (sale.SaleItems || []).map((it) => {
        const price = parseFloat(it.price) || 0;
        const qty = parseInt(it.quantity, 10) || 1;
        return {
          serviceName: it.itemName || "—",
          price: Math.round(price * 100) / 100,
          quantity: qty,
          lineTotal: Math.round(price * qty * 100) / 100,
        };
      });
      salesData.push({
        saleId: sale.id,
        createdAt: sale.createdAt,
        total: Math.round(total * 100) / 100,
        items,
      });
    }

    return res.status(200).json({
      success: true,
      data: {
        period: { fromDate: periodStartStr, toDate: periodEndStr },
        sales: salesData,
        totalRevenue: Math.round(totalRevenue * 100) / 100,
      },
    });
  } catch (err) {
    if (err.statusCode === 403) return res.status(403).json({ success: false, message: err.message });
    console.error("finance getRevenueBreakdown error:", err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
}

/**
 * GET /api/finance/cogs-breakdown?fromDate=...&toDate=...
 * Returns COGS line items (inventory used per sale) for the amount-detail dialog.
 */
async function getCogsBreakdown(req, res) {
  try {
    const organizationId = getOrganizationId(req);
    const branchId = await getBranchIdFromHeader(req, organizationId);
    const { periodStart, periodEnd, periodStartStr, periodEndStr } = getPeriodFromRequest(req);

    const saleWhere = { organizationId, status: "paid", createdAt: { [Op.gte]: periodStart, [Op.lte]: periodEnd } };
    if (branchId != null) saleWhere.branchId = branchId;
    const saleIdsInPeriod = new Set(
      (await Sale.findAll({ where: saleWhere, attributes: ["id"] })).map((s) => s.id)
    );

    const serviceWhere = {
      organizationId,
      serviceName: { [Op.like]: "POS Sale #%" },
      date: { [Op.gte]: periodStart, [Op.lte]: periodEnd },
    };
    if (branchId != null) serviceWhere.branchId = branchId;
    const posSaleServices = await Service.findAll({
      where: serviceWhere,
      attributes: ["id", "serviceName"],
      include: [
        {
          model: ServiceItem,
          as: "ServiceItems",
          required: true,
          attributes: ["quantity"],
          include: [{ model: Product, as: "Product", attributes: ["name", "purchasePriceExc"] }],
        },
      ],
    });

    const lines = [];
    let totalCogs = 0;
    for (const svc of posSaleServices) {
      const match = (svc.serviceName || "").match(/^POS Sale #(\d+)$/);
      const saleId = match ? parseInt(match[1], 10) : null;
      if (saleId == null || !saleIdsInPeriod.has(saleId)) continue;
      for (const it of svc.ServiceItems || []) {
        const qty = parseFloat(it.quantity) || 0;
        const prod = it.Product;
        const costPrice = prod && prod.purchasePriceExc != null ? parseFloat(prod.purchasePriceExc) || 0 : 0;
        const lineCost = qty * costPrice;
        totalCogs += lineCost;
        lines.push({
          saleId,
          productName: prod ? (prod.name || "—") : "—",
          quantity: Math.round(qty * 100) / 100,
          costPrice: Math.round(costPrice * 100) / 100,
          lineCost: Math.round(lineCost * 100) / 100,
        });
      }
    }

    return res.status(200).json({
      success: true,
      data: {
        period: { fromDate: periodStartStr, toDate: periodEndStr },
        lines,
        totalCogs: Math.round(totalCogs * 100) / 100,
      },
    });
  } catch (err) {
    if (err.statusCode === 403) return res.status(403).json({ success: false, message: err.message });
    console.error("finance getCogsBreakdown error:", err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
}

/**
 * GET /api/finance/expense-category-breakdown?fromDate=...&toDate=...&categoryName=Salaries
 * Returns itemized expenses in the given category for the period (for P&L / Cash Flow report sheet).
 */
async function getExpenseCategoryBreakdown(req, res) {
  try {
    const organizationId = getOrganizationId(req);
    const branchId = await getBranchIdFromHeader(req, organizationId);
    const { periodStartStr, periodEndStr } = getPeriodFromRequest(req);
    const categoryName = req.query.categoryName != null ? String(req.query.categoryName).trim() : null;
    if (!categoryName) {
      return res.status(400).json({ success: false, message: "categoryName is required" });
    }

    const category = await ExpenseCategory.findOne({
      where: { organizationId, name: categoryName },
      attributes: ["id", "name"],
    });
    if (!category) {
      return res.status(200).json({
        success: true,
        data: {
          categoryName,
          period: { fromDate: periodStartStr, toDate: periodEndStr },
          expenses: [],
          totalAmount: 0,
        },
      });
    }

    const expWhere = {
      organizationId,
      categoryId: category.id,
      date: { [Op.gte]: periodStartStr, [Op.lte]: periodEndStr },
    };
    if (branchId != null) expWhere.branchId = branchId;

    const expenses = await Expense.findAll({
      where: expWhere,
      attributes: ["id", "date", "description", "amount"],
      order: [["date", "ASC"], ["id", "ASC"]],
    });

    const items = expenses.map((exp) => {
      const amount = parseFloat(exp.amount) || 0;
      return {
        id: exp.id,
        date: exp.date,
        description: exp.description || null,
        amount: Math.round(amount * 100) / 100,
      };
    });
    const totalAmount = items.reduce((sum, i) => sum + i.amount, 0);

    return res.status(200).json({
      success: true,
      data: {
        categoryName: category.name,
        period: { fromDate: periodStartStr, toDate: periodEndStr },
        expenses: items,
        totalAmount: Math.round(totalAmount * 100) / 100,
      },
    });
  } catch (err) {
    if (err.statusCode === 403) return res.status(403).json({ success: false, message: err.message });
    console.error("finance getExpenseCategoryBreakdown error:", err);
    return res.status(500).json({ success: false, message: "Server error" });
  }
}

module.exports = { getProfitLoss, getCashFlow, getReceivables, getRevenueBreakdown, getCogsBreakdown, getExpenseCategoryBreakdown };
