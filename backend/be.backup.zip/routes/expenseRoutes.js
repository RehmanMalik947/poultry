const express = require("express");
const { protectStaffOrOrganization } = require("../middleware/authMiddleware");
const { getSummary, getAll, getById, create, update, remove } = require("../controllers/expenseController");

const router = express.Router();

router.use(protectStaffOrOrganization);

router.get("/summary", getSummary);
router.get("/", getAll);
router.get("/:id", getById);
router.post("/", create);
router.put("/:id", update);
router.delete("/:id", remove);

module.exports = router;
