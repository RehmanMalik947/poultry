const express = require("express");
const router = express.Router();
const { protectOrganization } = require("../middleware/authMiddleware");
const {
  createBranch,
  getAllBranches,
  getBranchById,
  updateBranch,
  deleteBranch,
} = require("../controllers/branchController");

router.use(protectOrganization);

router.post("/", createBranch);
router.get("/", getAllBranches);
router.get("/:id", getBranchById);
router.put("/:id", updateBranch);
router.delete("/:id", deleteBranch);

module.exports = router;
