const express = require("express");
const router = express.Router();
const registerController = require("../controllers/registerController");
const { protectStaffOrOrganization } = require("../middleware/authMiddleware");

router.use(protectStaffOrOrganization);

// The middleware checking auth and permissions will be applied in app.js
router.get("/current", registerController.getCurrentRegister);
router.post("/open", registerController.openRegister);
router.post("/close", registerController.closeRegister);
router.post("/transaction", registerController.addTransaction);

module.exports = router;
