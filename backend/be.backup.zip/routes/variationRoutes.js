const express = require("express");
const router = express.Router();
const controller = require("../controllers/variationController");
const { protectStaffOrOrganization } = require("../middleware/authMiddleware");

// All routes require authentication
router.use(protectStaffOrOrganization);

router.get("/", controller.getAll);
router.get("/:id", controller.getById);
router.post("/", controller.create);
router.put("/:id", controller.update);
router.delete("/:id", controller.remove);

module.exports = router;
