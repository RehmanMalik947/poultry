const express = require("express");
const router = express.Router();
const { register, login, changePassword } = require("../controllers/authController");
const { protectStaffOrOrganization } = require("../middleware/authMiddleware");

// Mounted at /api/auth
// POST /api/auth/register — body: { organizationName, username, email, phone, emergencyContact?, address?, totalEmployees?, industryCategory?, timezone? }
// POST /api/auth/login    — body: { login, password } — login is username or email
router.post("/register", register);
router.post("/login", login);
router.put("/change-password", protectStaffOrOrganization, changePassword);

module.exports = router;
