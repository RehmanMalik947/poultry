const express = require("express");
const { protectStaffOrOrganization } = require("../middleware/authMiddleware");
const {
  startSale,
  addItemToSale,
  removeItemFromSale,
  getCurrentSale,
  updateSale,
  processPayment,
  getSalesList,
  deleteSale,
  getCustomers,
  getBanks,
  submitSale,
  createSaleReturn,
  listSaleReturns,
  getSaleReturnById,
  addSaleReturnPayment,
  deleteSaleReturn
} = require("../controllers/saleController");

const router = express.Router();

router.use(protectStaffOrOrganization);

router.get("/sales", getSalesList);
router.get("/customers", getCustomers);
router.get("/sale/:saleId", getCurrentSale);
router.post("/sale/submit", submitSale);
router.patch("/sale/:saleId", updateSale);
router.delete("/sale/:saleId", deleteSale);
router.post("/sale/:saleId/item", addItemToSale);
router.delete("/sale/:saleId/item/:itemId", removeItemFromSale);
router.post("/sale/:saleId/pay", processPayment);
router.get("/banks", getBanks);
router.post("/returns", createSaleReturn);
router.get("/returns", listSaleReturns);
router.get("/returns/:id", getSaleReturnById);
router.post("/returns/:id/pay", addSaleReturnPayment);
router.delete("/returns/:id", deleteSaleReturn);

module.exports = router;
