const express = require("express");
const router = express.Router();
const { protectStaffOrOrganization } = require("../middleware/authMiddleware");
const {
  getAllRoles,
  createRole,
  getRoleById,
  updateRole,
  deleteRole,
} = require("../controllers/roleController");

router.use(protectStaffOrOrganization);

router.get("/", getAllRoles);
router.post("/", createRole);
router.get("/:id", getRoleById);
router.put("/:id", updateRole);
router.delete("/:id", deleteRole);

module.exports = router;
