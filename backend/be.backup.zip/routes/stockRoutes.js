const express = require("express");
const { protectStaffOrOrganization } = require("../middleware/authMiddleware");

const {
  getAllStocks,
  getStockById,
  manageStock,
  getLowStock,
  getVariance,
  transferStock,
  getStockLogs,
  getAllAdjustments,
  createAdjustment,
  getAllTransfers,
  createBulkTransfer,
} = require("../controllers/stockController");

const router = express.Router();

router.use(protectStaffOrOrganization);

// ✅ Specific routes FIRST
router.get("/", getAllStocks);
router.get("/low", getLowStock);
router.get("/variance", getVariance);
router.get("/logs", getStockLogs);      // ← moved up, before /:id

router.post("/manage", manageStock);
// Aakhir mein baki routes ke sath yeh add karein
router.get("/adjustments", getAllAdjustments);
router.post("/adjustments", createAdjustment);

router.get("/transfers", getAllTransfers);
router.post("/transfers", createBulkTransfer);

router.post("/transfer", transferStock);

// ✅ Param route LAST
router.get("/:id", getStockById);       // ← always last

module.exports = router;