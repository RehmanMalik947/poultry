const express = require("express");
const router = express.Router();
const bankController = require("../controllers/bankController");
const { protectStaffOrOrganization } = require("../middleware/authMiddleware");

router.use(protectStaffOrOrganization);

router.get("/", bankController.getAllBanks);
router.get("/:id", bankController.getBankById);
router.get("/:id/transactions", bankController.getBankTransactions);
router.post("/", bankController.createBank);
router.put("/:id", bankController.updateBank);
router.delete("/:id", bankController.deleteBank);

module.exports = router;
