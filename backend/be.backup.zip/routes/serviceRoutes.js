const express = require("express");
const { protectStaffOrOrganization } = require("../middleware/authMiddleware");
const { getAll, getById, getCogs, create, update, remove } = require("../controllers/serviceController");

const router = express.Router();

router.use(protectStaffOrOrganization);

router.get("/", getAll);
router.get("/cogs", getCogs);
router.get("/:id", getById);
router.post("/", create);
router.put("/:id", update);
router.delete("/:id", remove);

module.exports = router;
