const express = require("express");
const { protectStaffOrOrganization } = require("../middleware/authMiddleware");
const { getAll, getById, create, update, remove } = require("../controllers/attendanceController");

const router = express.Router();

router.use(protectStaffOrOrganization);

// Bulk route (specific)
router.post("/bulk", create);

// Regular CRUD routes
router.get("/", getAll);
router.get("/:id", getById);
router.post("/", create);
router.put("/:id", update);
router.delete("/:id", remove);

module.exports = router;