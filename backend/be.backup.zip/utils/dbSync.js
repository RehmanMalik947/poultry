const { sequelize } = require("../config/db");
require("../models"); // Load all models and associations
const { SuperAdmin } = require("../models/superAdmin");
const { User } = require("../models");

async function syncDB() {
  try {
    console.log("🔄 Starting Database Sync...");

    // 1. Sync critical models without 'alter' to avoid MySQL "Too many keys" errors
    await SuperAdmin.sync(); 
    await User.sync();

    // 2. Sync everything else with 'alter: true'
    // This automatically handles adding new columns for most tables
    // await sequelize.sync({ alter: true });
    await sequelize.sync({ alter: true });

    console.log("✅ Database synchronized successfully.");
  } catch (error) {
    console.error("❌ Database sync failed:");

console.error("Message:", error.message);
console.error("Table:", error.table);
console.error("SQL:", error.sql);
console.error("Parent:", error.parent);
console.error("Original:", error.original);
    // We don't want to crash the whole app if a sync fails, 
    // but we should know about it.
  }
}

module.exports = { syncDB };
